Para la correcta visualización de los archivos html debe tenerse
instalado jsMath

http://www.math.union.edu/~dpvc/jsmath/

Este software integra html y latex.


Alternativamente, se pueden visualizar directamente en 

http://www.unioviedo.es/galiano/index.php/menuteaching/menuprocesamiento

O, simplemente, usar los pdf's.
